#define ENA 9         //电机驱动设置 ENA, IN1, IN2 为一组 ENB, IN3, IN4 为一组，ENB组未设置
#define IN1 7           
#define IN2 6
#define ENB 3        
#define IN3 5           
#define IN4 4

#define RIN1 13         //四路循迹传感器引脚，根据自己情况设置
#define RIN2 12
#define RIN3 11
#define RIN4 10

#define DEFSPD 100   
#define ADPSPD 20 

void setup() {
  // put your setup code here, to run once:
  pinMode(ENA,OUTPUT);
  pinMode(IN1,OUTPUT);
  pinMode(IN2,OUTPUT);
   
}

void loop() {
  // put your main code here, to run repeatedly:
  analogWrite(ENA, 200);
  analogWrite(ENB, 0);   
  digitalWrite(IN1,HIGH);
  digitalWrite(IN2,LOW);
}
